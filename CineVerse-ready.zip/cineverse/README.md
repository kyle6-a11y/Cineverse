# CineVerse

A responsive, mobile-friendly movie and series discovery app. Built with React + Vite, an Express API proxy, and TMDB metadata. The same web app can be installed as a PWA on supported mobile browsers.

## Included in this starter

- Search across movie and TV metadata
- Trending/popular, top-rated, now-playing/on-air collections
- Movie/series type filters and paginated results
- Detail view with synopsis, genres, release year, rating, cast and official YouTube trailer link when available
- Browser-local watchlist (localStorage)
- Responsive desktop/mobile layouts and installable-web-app manifest
- Server-side API key handling and a small in-memory metadata cache

**This is a working discovery starter, not a licensed video streaming service.** It does not host, download, or unlock copyrighted films or episodes.

## Requirements

- Node.js 20+ recommended
- Optional: a TMDB API key for the live catalogue (demo mode works without one)
- Internet access for TMDB metadata/posters and YouTube trailer links

## Run locally

1. Unzip the project and open a terminal in the `cineverse` folder.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Copy `.env.example` to `.env` and set `TMDB_API_KEY` to your own key. Keep this key private; do not add it to frontend variables or commit `.env`.
4. Start the frontend and backend:

   ```bash
   npm run dev
   ```

5. Open the Vite URL shown in the terminal (normally `http://localhost:5173`).

For a production build, run `npm run build` and then `npm start`. The Express server serves the compiled `dist` app and the API on the same port. Set `PORT` in the host environment.

## Architecture

```text
Browser / installed PWA
        |
        | /api/*
        v
Express server (server/index.js)
        |
        | private TMDB API key
        v
TMDB API
```

When no TMDB key is configured, the server serves a built-in demo catalogue so the app is immediately usable offline from the provider. To get live catalogue data, configure the TMDB key. The browser never receives the TMDB API key. Vite proxies `/api` to Express in development. In production, Express serves both the compiled web app and API, so one deployment can serve both.

## API routes

- `GET /api/health` — server health and whether a provider key is configured
- `GET /api/discover?kind=all|movie|tv&category=trending|popular|top_rated|now_playing&page=1`
- `GET /api/search?q=batman&page=1`
- `GET /api/title/:kind/:id` — metadata, videos, cast and watch-provider data

TMDB API does not promise that every region has every provider/title. Check the current TMDB terms and attribution requirements before public launch. Ratings are supplied by TMDB; do not present sample ratings as your own editorial ratings.

## Database plan for a production version

This starter stores a personal watchlist in the current browser, which is useful for a demo but does not sync across devices. For accounts and cross-device sync, use PostgreSQL (for example, Supabase or a managed PostgreSQL service) with migrations such as:

```sql
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

create table watchlist_items (
  user_id uuid not null references profiles(id) on delete cascade,
  provider text not null default 'tmdb',
  provider_title_id bigint not null,
  media_type text not null check (media_type in ('movie', 'tv')),
  created_at timestamptz not null default now(),
  primary key (user_id, provider, provider_title_id, media_type)
);

create table watch_history (
  id bigint generated always as identity primary key,
  user_id uuid not null references profiles(id) on delete cascade,
  provider_title_id bigint not null,
  media_type text not null check (media_type in ('movie', 'tv')),
  watched_at timestamptz not null default now(),
  progress_seconds integer not null default 0
);

-- Only use this for content for which you have streaming rights.
create table licensed_playback_assets (
  id bigint generated always as identity primary key,
  provider_title_id bigint not null,
  media_type text not null check (media_type in ('movie', 'tv')),
  region_code text not null,
  playback_manifest_url text not null,
  rights_start timestamptz,
  rights_end timestamptz,
  constraint rights_window_valid check (rights_end is null or rights_start is null or rights_end > rights_start)
);
```

Production security:
- Enable row-level security; users may only read/write their own watchlist/history.
- Never ship a database service-role key or provider secret to the browser.
- Validate every request, add rate limiting, and cap pagination/search lengths.
- Add migrations, backups, monitoring, error reporting and account deletion.
- Store playback manifests privately and issue short-lived signed playback URLs only after checking entitlement and region.

## Streaming and copyright

A catalogue API provides metadata, artwork and sometimes links to trailers or viewing providers; it does not grant rights to stream a full movie or series. To offer full playback, negotiate distribution/licensing rights for each title, territory, platform and time window, or integrate a legitimate video provider whose contract grants those rights. You will also need a video pipeline (or licensed streaming provider), adaptive HLS/DASH playback, a CDN, access controls, content protection/DRM where required, age ratings, takedown process, and royalty/reporting obligations. Do not scrape streaming services or embed unauthorised copies.

## Suggested roadmap

1. **MVP:** deploy this app, verify TMDB attribution/terms, test mobile layouts and search.
2. **Accounts:** add Supabase Auth/Postgres, row-level security, synced watchlists and profiles.
3. **Better discovery:** filters by genre/year/language, recommendations, title pages, regional availability and accessibility metadata.
4. **Legal playback:** only after rights are secured, add a licensed playback service, entitlement checks and a region-aware availability catalogue.
5. **Launch hardening:** privacy policy, cookie/analytics choices, accessibility review, rate limiting, backups and monitoring.

## Deployment

Deploy this as one Node-capable service (for example Render, Railway, Fly.io, or a container host):

1. Push this folder to a private/public Git repository, excluding `.env`.
2. Create a web service with build command `npm install && npm run build`.
3. Set start command `npm start`.
4. Add `TMDB_API_KEY` and `PORT` in the host's secret/environment settings.
5. Use HTTPS and configure a custom domain if desired.
6. Test `/api/health`, search, details, error states and mobile browser behavior.

Static-only hosting cannot run the Express API. If deploying the frontend to a static host, deploy the API separately and configure a server-side API base URL plus CORS. Do not expose the TMDB key in `VITE_*` variables.

## Mobile

This responsive app runs in mobile browsers. The included manifest is a starting point for installation as a PWA; full offline caching and app-store distribution are not configured yet. For App Store/Google Play distribution, a later Capacitor wrapper or a React Native client can reuse the API. Store policies and platform requirements apply.

## Attribution

TMDB data and images are used under TMDB's API terms. Before public release, follow TMDB's current attribution/logo requirements and confirm commercial/non-commercial usage permissions for your use case. TMDB is not endorsing this project.
