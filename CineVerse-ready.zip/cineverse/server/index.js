import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const port = Number(process.env.PORT || 3001);
const apiKey = process.env.TMDB_API_KEY;
const clientOrigin = process.env.CLIENT_ORIGIN || 'http://localhost:5173';
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(cors({ origin: clientOrigin }));
app.use(express.json({ limit: '20kb' }));


const demoTitles = [
  { id: 1, media_type: 'movie', title: 'Dune: Part Two', release_date: '2024-02-27', vote_average: 8.5, popularity: 100, poster_path: null, backdrop_path: null, overview: 'Paul Atreides unites with Chani and the Fremen while seeking revenge against the conspirators who destroyed his family.', genre_ids: [878, 12] },
  { id: 2, media_type: 'tv', name: 'Stranger Things', first_air_date: '2016-07-15', vote_average: 8.6, popularity: 99, poster_path: null, backdrop_path: null, overview: 'When a young boy vanishes, a small town uncovers a mystery involving secret experiments and supernatural forces.', genre_ids: [10765, 9648] },
  { id: 3, media_type: 'movie', title: 'Interstellar', release_date: '2014-11-07', vote_average: 8.7, popularity: 97, poster_path: null, backdrop_path: null, overview: 'A team of explorers travels beyond this galaxy to discover whether mankind has a future among the stars.', genre_ids: [12, 18, 878] },
  { id: 4, media_type: 'tv', name: 'The Last of Us', first_air_date: '2023-01-15', vote_average: 8.5, popularity: 95, poster_path: null, backdrop_path: null, overview: 'Twenty years after civilisation is destroyed, a hardened survivor is hired to escort a teenager across a dangerous world.', genre_ids: [18, 10759] },
  { id: 5, media_type: 'movie', title: 'The Batman', release_date: '2022-03-04', vote_average: 7.8, popularity: 93, poster_path: null, backdrop_path: null, overview: 'Batman investigates corruption in Gotham City when a sadistic killer leaves a trail of cryptic clues.', genre_ids: [80, 9648, 53] },
  { id: 6, media_type: 'tv', name: 'Wednesday', first_air_date: '2022-11-23', vote_average: 8.0, popularity: 91, poster_path: null, backdrop_path: null, overview: 'Wednesday Addams investigates a murder mystery while making new friends and foes at Nevermore Academy.', genre_ids: [35, 80, 9648] },
  { id: 7, media_type: 'movie', title: 'Oppenheimer', release_date: '2023-07-21', vote_average: 8.3, popularity: 89, poster_path: null, backdrop_path: null, overview: 'The story of J. Robert Oppenheimer and his role in the development of the atomic bomb.', genre_ids: [18, 36] },
  { id: 8, media_type: 'tv', name: 'The Bear', first_air_date: '2022-06-23', vote_average: 8.5, popularity: 87, poster_path: null, backdrop_path: null, overview: 'A young chef returns to Chicago to run his family sandwich shop, transforming the kitchen and himself along the way.', genre_ids: [18, 35] },
  { id: 9, media_type: 'movie', title: 'Spider-Man: Across the Spider-Verse', release_date: '2023-06-02', vote_average: 8.6, popularity: 85, poster_path: null, backdrop_path: null, overview: 'Miles Morales embarks on an adventure across the multiverse, encountering a team of Spider-People.', genre_ids: [16, 28, 12] },
  { id: 10, media_type: 'tv', name: 'House of the Dragon', first_air_date: '2022-08-21', vote_average: 8.3, popularity: 83, poster_path: null, backdrop_path: null, overview: 'The history of House Targaryen unfolds nearly two centuries before the events of Game of Thrones.', genre_ids: [18, 10765, 10759] },
  { id: 11, media_type: 'movie', title: 'John Wick: Chapter 4', release_date: '2023-03-24', vote_average: 7.6, popularity: 81, poster_path: null, backdrop_path: null, overview: 'John Wick uncovers a path to defeating the High Table, but faces a powerful new enemy.', genre_ids: [28, 53, 80] },
  { id: 12, media_type: 'tv', name: 'Severance', first_air_date: '2022-02-18', vote_average: 8.7, popularity: 79, poster_path: null, backdrop_path: null, overview: 'Employees at a mysterious company undergo a procedure that separates their work memories from their personal lives.', genre_ids: [18, 9648, 878] },
  { id: 13, media_type: 'movie', title: 'The Dark Knight', release_date: '2008-07-18', vote_average: 9.0, popularity: 77, poster_path: null, backdrop_path: null, overview: 'Batman faces the Joker, a criminal mastermind who plunges Gotham into chaos.', genre_ids: [28, 80, 18] },
  { id: 14, media_type: 'tv', name: 'Breaking Bad', first_air_date: '2008-01-20', vote_average: 9.5, popularity: 75, poster_path: null, backdrop_path: null, overview: 'A chemistry teacher diagnosed with cancer turns to manufacturing methamphetamine to secure his family’s future.', genre_ids: [18, 80] },
  { id: 15, media_type: 'movie', title: 'Coco', release_date: '2017-11-22', vote_average: 8.4, popularity: 73, poster_path: null, backdrop_path: null, overview: 'An aspiring young musician enters the Land of the Dead to discover his family history.', genre_ids: [16, 10751, 14] },
  { id: 16, media_type: 'tv', name: 'The Witcher', first_air_date: '2019-12-20', vote_average: 7.9, popularity: 71, poster_path: null, backdrop_path: null, overview: 'A mutated monster hunter struggles to find his place in a world where people often prove more wicked than beasts.', genre_ids: [18, 10765, 10759] },
  { id: 17, media_type: 'movie', title: 'Top Gun: Maverick', release_date: '2022-05-27', vote_average: 8.2, popularity: 69, poster_path: null, backdrop_path: null, overview: 'After decades of service, Pete Mitchell trains a new generation of pilots for a dangerous special assignment.', genre_ids: [28, 18] },
  { id: 18, media_type: 'tv', name: 'Squid Game', first_air_date: '2021-09-17', vote_average: 7.9, popularity: 67, poster_path: null, backdrop_path: null, overview: 'Hundreds of cash-strapped contestants accept an invitation to compete in children’s games for a tempting prize.', genre_ids: [18, 9648, 28] },
  { id: 19, media_type: 'movie', title: 'Everything Everywhere All at Once', release_date: '2022-03-25', vote_average: 7.8, popularity: 65, poster_path: null, backdrop_path: null, overview: 'An exhausted laundromat owner becomes the unlikely hero of a multiverse-spanning adventure.', genre_ids: [28, 12, 878] },
  { id: 20, media_type: 'tv', name: 'The Office', first_air_date: '2005-03-24', vote_average: 8.6, popularity: 63, poster_path: null, backdrop_path: null, overview: 'A mockumentary on a group of typical office workers and their everyday lives.', genre_ids: [35] }
];
function demoSearch(query) {
  const q = query.toLowerCase();
  return demoTitles.filter(t => `${t.title || t.name} ${t.overview}`.toLowerCase().includes(q));
}

const cache = new Map();
async function tmdb(endpoint, params = {}) {
  if (!apiKey) {
    const error = new Error('TMDB_API_KEY is missing. Copy .env.example to .env and add your key.');
    error.status = 503;
    throw error;
  }
  const url = new URL(`https://api.themoviedb.org/3/${endpoint}`);
  url.searchParams.set('api_key', apiKey);
  url.searchParams.set('language', 'en-GB');
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== '') url.searchParams.set(key, String(value));
  }
  const cacheKey = url.toString();
  const saved = cache.get(cacheKey);
  if (saved && saved.expires > Date.now()) return saved.value;
  const response = await fetch(url);
  if (!response.ok) {
    const error = new Error(`Movie catalogue provider returned ${response.status}.`);
    error.status = response.status === 401 ? 502 : response.status;
    throw error;
  }
  const data = await response.json();
  cache.set(cacheKey, { value: data, expires: Date.now() + 5 * 60 * 1000 });
  return data;
}

app.get('/api/health', (_req, res) => res.json({ ok: true, providerConfigured: Boolean(apiKey), mode: apiKey ? 'live' : 'demo' }));

app.get('/api/discover', async (req, res, next) => {
  try {
    const kind = ['movie', 'tv'].includes(req.query.kind) ? req.query.kind : 'all';
    const category = ['trending', 'popular', 'top_rated', 'now_playing', 'on_the_air'].includes(req.query.category)
      ? req.query.category : 'trending';
    const page = Math.max(1, Math.min(500, Number.parseInt(req.query.page || '1', 10) || 1));
    const tasks = [];
    const types = kind === 'all' ? ['movie', 'tv'] : [kind];
    for (const type of types) {
      let endpoint;
      if (category === 'trending') endpoint = `${type}/popular`;
      else if (category === 'popular') endpoint = `${type}/popular`;
      else if (category === 'top_rated') endpoint = `${type}/top_rated`;
      else if (category === 'now_playing') endpoint = type === 'movie' ? 'movie/now_playing' : 'tv/on_the_air';
      else endpoint = type === 'movie' ? 'movie/now_playing' : 'tv/on_the_air';
      tasks.push(tmdb(endpoint, { page }).then(data => (data.results || []).map(item => ({ ...item, media_type: type }))));
    }
    const groups = await Promise.all(tasks);
    const results = groups.flat().sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
    res.json({ results, page, total_pages: 500 });
  } catch (err) { next(err); }
});

app.get('/api/search', async (req, res, next) => {
  try {
    const query = String(req.query.q || '').trim().slice(0, 120);
    if (!query) return res.json({ results: [], page: 1, total_pages: 0 });
    const page = Math.max(1, Math.min(500, Number.parseInt(req.query.page || '1', 10) || 1));
    const data = await tmdb('search/multi', { query, page, include_adult: false });
    res.json({ ...data, results: (data.results || []).filter(x => ['movie', 'tv'].includes(x.media_type)) });
  } catch (err) { next(err); }
});

app.get('/api/title/:kind/:id', async (req, res, next) => {
  try {
    const kind = req.params.kind === 'tv' ? 'tv' : 'movie';
    const id = Number.parseInt(req.params.id, 10);
    if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid title ID.' });
    const data = await tmdb(`${kind}/${id}`, { append_to_response: 'videos,credits,watch/providers' });
    res.json({ ...data, media_type: kind });
  } catch (err) { next(err); }
});

app.use((err, _req, res, _next) => {
  console.error(err.message);
  res.status(err.status || 500).json({ error: err.message || 'Unexpected server error.' });
});

// In production, serve the compiled Vite app from the same origin.
const distPath = path.resolve(__dirname, '../dist');
app.use(express.static(distPath));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(distPath, 'index.html'), err => { if (err) next(); });
});

app.listen(port, () => console.log(`CineVerse API listening on http://localhost:${port}`));