import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Bookmark, BookmarkCheck, Clapperboard, Compass, Film, Menu, Play, Search, Sparkles, Star, Tv, X, ChevronRight, ArrowLeft, Info } from 'lucide-react';
import './styles.css';

const IMAGE = 'https://image.tmdb.org/t/p/';
const poster = (path, size = 'w500') => path ? `${IMAGE}${size}${path}` : '';
const titleName = item => item.title || item.name || 'Untitled';
const yearOf = item => (item.release_date || item.first_air_date || '').slice(0, 4);
const kindOf = item => item.media_type === 'tv' || item.first_air_date ? 'tv' : 'movie';
const loadSaved = () => { try { return JSON.parse(localStorage.getItem('cineverse-watchlist') || '[]'); } catch { return []; } };

function App() {
  const [section, setSection] = useState('Discover');
  const [kind, setKind] = useState('all');
  const [category, setCategory] = useState('trending');
  const [query, setQuery] = useState('');
  const [debounced, setDebounced] = useState('');
  const [results, setResults] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(loadSaved);
  const [active, setActive] = useState(null);
  const [details, setDetails] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);

  useEffect(() => { const timer = setTimeout(() => setDebounced(query.trim()), 300); return () => clearTimeout(timer); }, [query]);
  useEffect(() => { localStorage.setItem('cineverse-watchlist', JSON.stringify(saved)); }, [saved]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true); setError('');
    const url = debounced
      ? `/api/search?q=${encodeURIComponent(debounced)}&page=${page}`
      : `/api/discover?kind=${kind}&category=${category}&page=${page}`;
    fetch(url).then(async r => { const data = await r.json(); if (!r.ok) throw new Error(data.error || 'Could not load titles.'); return data; })
      .then(data => { if (!cancelled) { setResults(data.results || []); setTotalPages(Math.min(data.total_pages || 1, 500)); } })
      .catch(err => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [debounced, kind, category, page]);

  useEffect(() => {
    if (!active) { setDetails(null); return; }
    let cancelled = false;
    setDetailLoading(true);
    fetch(`/api/title/${kindOf(active)}/${active.id}`)
      .then(async r => { const d = await r.json(); if (!r.ok) throw new Error(d.error || 'Could not load title details.'); return d; })
      .then(d => { if (!cancelled) setDetails(d); })
      .catch(err => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setDetailLoading(false); });
    return () => { cancelled = true; };
  }, [active]);

  const visible = useMemo(() => section === 'My List' ? results.filter(x => saved.some(s => s.id === x.id && kindOf(s) === kindOf(x))) : results, [results, section, saved]);
  const displayItems = section === 'My List' && !debounced ? saved.filter(x => kind === 'all' || kindOf(x) === kind) : visible;
  const isSaved = item => saved.some(s => s.id === item.id && kindOf(s) === kindOf(item));
  const toggleSaved = item => setSaved(old => isSaved(item) ? old.filter(s => !(s.id === item.id && kindOf(s) === kindOf(item))) : [{ ...item, media_type: kindOf(item) }, ...old]);
  const changeSection = next => { setSection(next); setActive(null); setMobileMenu(false); setPage(1); };
  const resetFilters = () => { setQuery(''); setDebounced(''); setKind('all'); setCategory('trending'); setPage(1); };

  return <div className="app-shell">
    <aside className={`sidebar ${mobileMenu ? 'open' : ''}`}>
      <a className="brand" href="#" onClick={e => {e.preventDefault(); changeSection('Discover');}}>
        <span className="brand-mark"><Clapperboard size={23}/></span><span>Cine<span>Verse</span><small>YOUR WORLD OF ENTERTAINMENT</small></span>
      </a>
      <div className="nav-label">MENU</div>
      <button className={`nav-item ${section === 'Discover' ? 'selected' : ''}`} onClick={() => changeSection('Discover')}><Compass size={19}/> Discover</button>
      <button className={`nav-item ${section === 'My List' ? 'selected' : ''}`} onClick={() => changeSection('My List')}><Bookmark size={19}/> My List <span className="count">{saved.length}</span></button>
      <div className="sidebar-note"><Sparkles size={18}/><strong>Find your next obsession.</strong><p>Discover stories worth staying in for.</p></div>
      <div className="sidebar-foot">CineVerse · Discovery edition<br/>Metadata powered by TMDB</div>
    </aside>

    {mobileMenu && <button aria-label="Close navigation" className="scrim" onClick={() => setMobileMenu(false)} />}
    <main className="main">
      <header className="topbar">
        <button className="icon-button mobile-only" aria-label="Open navigation" onClick={() => setMobileMenu(true)}><Menu/></button>
        <div className="breadcrumbs">Home <ChevronRight size={14}/> <span>{section}</span></div>
        <div className="top-actions"><span className="free-pill"><span/> FREE DISCOVERY</span><div className="avatar">CV</div></div>
      </header>

      {!active ? <>
        <section className="hero">
          <div className="hero-copy">
            <span className="eyebrow"><Sparkles size={14}/> YOUR NEXT FAVOURITE STARTS HERE</span>
            <h1>{section === 'My List' ? <>Your personal<br/><em>watchlist.</em></> : <>Stories that<br/><em>stay with you.</em></>}</h1>
            <p>{section === 'My List' ? 'Everything you want to watch, gathered in one place.' : 'Explore trending movies, unforgettable series, and hidden gems from around the world.'}</p>
            <div className="hero-actions">
              <button className="primary-button" onClick={() => document.getElementById('library')?.scrollIntoView({behavior:'smooth'})}><Compass size={17}/> Explore library</button>
              <button className="secondary-button" onClick={() => changeSection('My List')}><Bookmark size={17}/> My watchlist</button>
            </div>
          </div>
          <div className="hero-art" aria-hidden="true"><div className="orb orb-one"/><div className="orb orb-two"/><div className="hero-disc"><Film size={76} strokeWidth={1.1}/></div><span className="floating-tag tag-one">✦ &nbsp; YOUR NEXT FAVOURITE</span><span className="floating-tag tag-two">MOVIES · SERIES · STORIES</span></div>
          <div className="hero-grain"/>
        </section>

        <section id="library" className="library-section">
          <div className="section-heading"><div><span className="eyebrow muted">THE CINEVERSE COLLECTION</span><h2>{section === 'My List' ? 'Saved for later' : debounced ? `Results for “${debounced}”` : category === 'trending' ? 'Popular right now' : category === 'top_rated' ? 'Top rated' : category === 'now_playing' ? 'Now playing & on air' : 'Popular picks'}</h2><p>{section === 'My List' ? `${saved.length} titles saved in this browser` : 'A universe of entertainment, waiting to be discovered.'}</p></div><div className="section-counter">{displayItems.length} <span>TITLES</span></div></div>
          <div className="controls">
            <label className="search-box"><Search size={19}/><input value={query} onChange={e => {setQuery(e.target.value);setPage(1);}} placeholder="Search movies, series, genres..." aria-label="Search movies and series"/>{query && <button onClick={() => setQuery('')} aria-label="Clear search"><X size={16}/></button>}</label>
            <div className="filters">
              <div className="segmented" aria-label="Type filter">{[['all','All'],['movie','Movies'],['tv','Series']].map(([v,l])=><button key={v} className={kind===v?'active':''} onClick={()=>{setKind(v);setPage(1);}}>{l}</button>)}</div>
              {!debounced && section !== 'My List' && <select value={category} onChange={e=>{setCategory(e.target.value);setPage(1);}} aria-label="Sort collection"><option value="trending">Trending</option><option value="popular">Popular</option><option value="top_rated">Top rated</option><option value="now_playing">Now playing / on air</option></select>}
            </div>
          </div>

          {error && <div className="error-panel"><Info size={20}/><div><strong>Catalogue unavailable</strong><p>{error}</p><small>Check your TMDB API key and that the server is running. Setup steps are in README.md.</small></div></div>}
          {loading && <div className="poster-grid">{Array.from({length:8},(_,i)=><div className="skeleton" key={i}/>)}</div>}
          {!loading && !error && displayItems.length > 0 && <div className="poster-grid">{displayItems.map(item=><article className="poster-card" key={`${kindOf(item)}-${item.id}`}>
            <button className="poster-button" onClick={()=>setActive(item)} aria-label={`View ${titleName(item)}`}>
              <div className="poster-frame">{poster(item.poster_path) ? <img src={poster(item.poster_path)} alt={`${titleName(item)} poster`} loading="lazy"/> : <div className="poster-placeholder"><Film size={38}/><span>{titleName(item)}</span></div>}
                <span className="type-chip">{kindOf(item)==='movie' ? <><Film size={12}/> FILM</> : <><Tv size={12}/> SERIES</>}</span>
                <span className="poster-hover"><Play size={21} fill="currentColor"/> View details</span>
              </div>
            </button>
            <button className={`save-button ${isSaved(item)?'saved':''}`} aria-label={isSaved(item)?'Remove from watchlist':'Add to watchlist'} onClick={()=>toggleSaved(item)}>{isSaved(item)?<BookmarkCheck size={17}/>:<Bookmark size={17}/>}</button>
            <div className="poster-meta"><h3>{titleName(item)}</h3><div className="poster-sub"><span>{yearOf(item)||'Year unknown'}</span><span className="rating"><Star size={13} fill="currentColor"/>{Number(item.vote_average || 0).toFixed(1)}</span></div></div>
          </article>)}</div>}
          {!loading && !error && displayItems.length === 0 && <div className="empty-state"><div className="empty-icon"><Search size={28}/></div><h3>{section==='My List' && !debounced ? 'Your watchlist is waiting' : 'No titles found'}</h3><p>{section==='My List' && !debounced ? 'Tap the bookmark on any movie or series to save it here.' : 'Try another title or clear your filters.'}</p><button className="secondary-button" onClick={resetFilters}>Reset filters</button></div>}
          {!debounced && section !== 'My List' && totalPages > 1 && <div className="pagination"><button disabled={page<=1} onClick={()=>{setPage(p=>p-1);document.getElementById('library')?.scrollIntoView({behavior:'smooth'});}}>Previous</button><span>Page {page} of {totalPages}</span><button disabled={page>=totalPages} onClick={()=>{setPage(p=>p+1);document.getElementById('library')?.scrollIntoView({behavior:'smooth'});}}>Next page <ChevronRight size={15}/></button></div>}
        </section>
        <footer className="footer"><span>© {new Date().getFullYear()} CineVerse</span><span>Discover stories. Find your next favourite.</span><span>Movie data by TMDB</span></footer>
      </> : <section className="detail-page">
        <button className="back-button" onClick={()=>setActive(null)}><ArrowLeft size={17}/> Back to collection</button>
        {detailLoading && <div className="detail-skeleton"/>}
        {details && <div className="detail-layout">
          <div className="detail-backdrop" style={{backgroundImage:details.backdrop_path?`linear-gradient(0deg,#101017 0%,rgba(16,16,23,.25) 100%),url(${poster(details.backdrop_path,'w1280')})`:undefined}}/>
          <div className="detail-poster">{poster(details.poster_path)?<img src={poster(details.poster_path)} alt={`${titleName(details)} poster`}/>:<div className="poster-placeholder"><Film size={40}/></div>}</div>
          <div className="detail-copy"><span className="eyebrow muted">{kindOf(details)==='movie'?'FEATURE FILM':'SERIES'} · {yearOf(details)}</span><h1>{titleName(details)}</h1><div className="detail-facts"><span className="rating"><Star size={15} fill="currentColor"/>{Number(details.vote_average||0).toFixed(1)} / 10</span>{details.runtime && <span>{details.runtime} min</span>}{details.number_of_seasons && <span>{details.number_of_seasons} seasons</span>}{details.genres?.map(g=><span className="genre-chip" key={g.id}>{g.name}</span>)}</div><p className="overview">{details.overview || 'No synopsis is available yet.'}</p>
            <button className="primary-button" onClick={()=>toggleSaved(details)}>{isSaved(details)?<BookmarkCheck size={17}/>:<Bookmark size={17}/>} {isSaved(details)?'Saved to My List':'Add to My List'}</button>
            {details.credits?.cast?.length>0 && <div className="cast-block"><h3>Top cast</h3><p>{details.credits.cast.slice(0,6).map(c=>c.name).join(' · ')}</p></div>}
            {details.videos?.results?.some(v=>v.site==='YouTube' && ['Trailer','Teaser'].includes(v.type)) && <div className="trailer-block"><h3>Official trailer</h3><a className="secondary-button" target="_blank" rel="noreferrer" href={`https://www.youtube.com/watch?v=${details.videos.results.find(v=>v.site==='YouTube'&&['Trailer','Teaser'].includes(v.type)).key}`}><Play size={16}/> Watch trailer on YouTube</a></div>}
            {(() => {
              const language = typeof navigator !== 'undefined' ? navigator.language : 'en-GB';
              const region = (language.split('-')[1] || 'GB').toUpperCase();
              const providerResults = details['watch/providers']?.results || {};
              const watchData = providerResults[region] || providerResults.GB;
              const providerGroups = watchData ? [
                ['Free to watch', watchData.free],
                ['Free with ads', watchData.ads],
                ['Subscription', watchData.flatrate],
                ['Rent', watchData.rent],
                ['Buy', watchData.buy]
              ].filter(([, providers]) => providers?.length) : [];
              return <div className="providers-block"><h3>Where to watch</h3>
                {providerGroups.length ? <>
                  <p className="provider-region">Viewing options for {providerResults[region] ? region : 'the UK'} · availability can change.</p>
                  {providerGroups.map(([label, providers]) => <div className="provider-group" key={label}><strong>{label}</strong><p>{providers.map(provider => provider.provider_name).join(' · ')}</p></div>)}
                  {watchData.link && <a className="secondary-button" href={watchData.link} target="_blank" rel="noreferrer">View legal viewing options <ChevronRight size={15}/></a>}
                </> : <p className="provider-region">Streaming availability isn't available in this demo. With a TMDB API key configured, CineVerse can show regional services and link viewers to their legal viewing options.</p>}
              </div>;
            })()}
            <p className="rights-note"><Info size={15}/> CineVerse links to reported viewing options; availability depends on your region and provider. Full-film playback is not hosted by CineVerse.</p>
          </div>
        </div>}
      </section>}
    </main>
  </div>;
}

createRoot(document.getElementById('root')).render(<React.StrictMode><App/></React.StrictMode>);